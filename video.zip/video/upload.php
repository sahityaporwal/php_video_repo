<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle video upload
$targetDirectory = "upload/";
$targetFile = $targetDirectory . basename($_FILES["videoFile"]["name"]);
$uploadOk = 1;
$videoFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// Check if file already exists
if (file_exists($targetFile)) {
    echo "Sorry, the file already exists.";
    $uploadOk = 0;
}

// Check file size (adjust as needed)
if ($_FILES["videoFile"]["size"] > 100000000) { // 100 MB
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

// Allow certain video formats (add more if needed)
$allowedFormats = array("mp4", "avi", "mov");
if (!in_array($videoFileType, $allowedFormats)) {
    echo "Sorry, only MP4, AVI, and MOV files are allowed.";
    $uploadOk = 0;
}

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
} else {
    if (move_uploaded_file($_FILES["videoFile"]["tmp_name"], $targetFile)) {
        // File uploaded successfully, now insert into database
        $videoAddress = $targetFile;

        $sql = "INSERT INTO videos (video_address) VALUES ('$videoAddress')";
        if ($conn->query($sql) === TRUE) {
            echo "Video uploaded and record inserted successfully.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
