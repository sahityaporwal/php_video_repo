<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Assuming you have an ID of the video you want to retrieve
// $videoId = $_GET['id']; // Replace with how you retrieve the ID

$sql = "SELECT video_address FROM videos WHERE id = 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $videoAddress = $row['video_address'];
} else {
    echo "Video not found.";
    exit;
}

$conn->close();
?>



<!DOCTYPE html>
<html>
<head>
    <title>Play Video</title>
</head>
<body>
    <video controls>
        <source src="<?php echo $videoAddress; ?>" type="video/mp4">
        Your browser does not support the video tag.
    </video>
</body>
</html>
